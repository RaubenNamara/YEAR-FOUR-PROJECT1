var cryptridez = artifacts.require("./cryptridez.sol");

module.exports = function(deployer) {
  deployer.deploy(cryptridez);

};